puts "There are " + (24*365).to_s + " hours in a year."
puts "There are " + (60*24*365*10).to_s + " minutes in a decade."
puts "I am " + (60*24*365*25).to_s + " seconds old."
puts "Our dear author is " + (1111000000 / 60 / 60 / 24 / 365).to_s + " years old."
