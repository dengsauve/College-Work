<?php

$title = "Blog";
include 'includes/header.php';

?>

<h1>Blog</h1>

<hr/>

<article class="col-sm-12 blog">
  <h3>Can you dig it?</h3>
  <h3><small>Fossil site in Republic, WA open for business</small></h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eros ante, ullamcorper ac est vitae, accumsan euismod mi. Proin vestibulum ac nisi id tempor. Integer et dictum tortor, vitae auctor massa. Proin molestie luctus varius. Sed sit amet metus tincidunt, blandit ipsum a, imperdiet nisi. Nunc tempus metus ac cursus interdum. Donec commodo massa a neque tempor aliquet. Sed dictum porttitor risus tincidunt maximus.</p>

  <p>Aliquam vitae erat vulputate, cursus libero sed, imperdiet ipsum. Aliquam eget ligula nec erat dignissim pretium nec ut mi. Vivamus lobortis, libero eget eleifend bibendum, leo nulla vehicula justo, sit amet blandit odio libero nec ipsum. Vivamus erat ligula, scelerisque sed tellus a, facilisis bibendum sapien. Aenean euismod varius ultricies. Nunc sapien est, consectetur in neque ut, tincidunt facilisis purus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum tempus elit viverra libero elementum faucibus. Integer molestie laoreet elit. Maecenas justo neque, ultrices sit amet diam sit amet, suscipit pulvinar tellus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Cras dignissim quam quis sagittis tristique. Quisque enim elit, tempor id odio sed, euismod venenatis mi. Vivamus luctus eros ac nisi mollis lacinia.</p>

  <p>In a nunc metus. Donec id diam varius, tristique nibh id, hendrerit risus. In hac habitasse platea dictumst. Phasellus ac augue sed purus elementum varius. Vivamus pellentesque tristique neque, in laoreet mi pulvinar quis. Maecenas in turpis viverra, semper diam vitae, venenatis quam. Praesent at rutrum nunc, vitae imperdiet mauris.</p>
</article>

<article class="col-sm-12 blog">
  <h3>Fly me to the Moon</h3>
  <h3><small>Mica Flats ZipLine now open for business</small></h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eros ante, ullamcorper ac est vitae, accumsan euismod mi. Proin vestibulum ac nisi id tempor. Integer et dictum tortor, vitae auctor massa. Proin molestie luctus varius. Sed sit amet metus tincidunt, blandit ipsum a, imperdiet nisi. Nunc tempus metus ac cursus interdum. Donec commodo massa a neque tempor aliquet. Sed dictum porttitor risus tincidunt maximus.</p>

  <p>Aliquam vitae erat vulputate, cursus libero sed, imperdiet ipsum. Aliquam eget ligula nec erat dignissim pretium nec ut mi. Vivamus lobortis, libero eget eleifend bibendum, leo nulla vehicula justo, sit amet blandit odio libero nec ipsum. Vivamus erat ligula, scelerisque sed tellus a, facilisis bibendum sapien. Aenean euismod varius ultricies. Nunc sapien est, consectetur in neque ut, tincidunt facilisis purus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum tempus elit viverra libero elementum faucibus. Integer molestie laoreet elit. Maecenas justo neque, ultrices sit amet diam sit amet, suscipit pulvinar tellus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Cras dignissim quam quis sagittis tristique. Quisque enim elit, tempor id odio sed, euismod venenatis mi. Vivamus luctus eros ac nisi mollis lacinia.</p>

  <p>In a nunc metus. Donec id diam varius, tristique nibh id, hendrerit risus. In hac habitasse platea dictumst. Phasellus ac augue sed purus elementum varius. Vivamus pellentesque tristique neque, in laoreet mi pulvinar quis. Maecenas in turpis viverra, semper diam vitae, venenatis quam. Praesent at rutrum nunc, vitae imperdiet mauris.</p>
</article>

<?php

include 'includes/footer.php';

?>
