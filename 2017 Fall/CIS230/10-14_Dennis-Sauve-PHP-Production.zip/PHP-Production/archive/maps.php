<?php

$title = "Maps";
include 'includes/header.php';

?>

<h1>Maps</h1>

<?php

include 'includes/footer.php';

?>