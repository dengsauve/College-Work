<?php

  $title = "Contact Us";
  include 'includes/header.php';

?>

  <h1>Contact Us</h1>

<?php

  include 'includes/contactForm.php';
  include 'includes/footer.php';

?>