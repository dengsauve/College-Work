<?php

  $title = "default-page";
  include 'includes/header.php';


?>

<h1>Blog</h1>

<?php

  include 'includes/footer.php';

?>
