class PageController < ApplicationController
  def contact_us
  end

  def products
  end

  def preferences
  end

  def blog
  end

  def calendar
  end

  def articles
  end

  def login
  end
end
