module RestaurantsHelper
end
