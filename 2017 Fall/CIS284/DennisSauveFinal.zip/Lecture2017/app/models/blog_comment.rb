class BlogComment < ApplicationRecord
end
