require 'test_helper'

class BlogCommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
