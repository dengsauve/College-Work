require "application_system_test_case"

class BlogCommentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit blog_comments_url
  #
  #   assert_selector "h1", text: "BlogComment"
  # end
end
