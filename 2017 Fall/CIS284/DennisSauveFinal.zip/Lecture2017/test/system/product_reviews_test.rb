require "application_system_test_case"

class ProductReviewsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit product_reviews_url
  #
  #   assert_selector "h1", text: "ProductReview"
  # end
end
