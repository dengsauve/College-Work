class Review < ApplicationRecord
  belongs_to :restaurant
end
