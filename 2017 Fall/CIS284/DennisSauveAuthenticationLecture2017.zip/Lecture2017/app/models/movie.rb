class Movie < ApplicationRecord
end
